ATS Schedule Center (آخر نسخة)
- index.html : الموقع كاملًا. هذا الملف الذي يُرفع على GitHub.
- exam_plan_backup_before_reset.json : نسخة احتياطية (لا تُرفع).
الرفع: GitHub > Add file > Upload files > index.html > Commit changes. ثم Ctrl+Shift+R.
تنبيه: المراقبة والإشغال والإشعارات المشتركة تعمل على رابط claude.ai فقط.
